create view binkingreocrd as
select `b`.`bookID`          AS `bookID`,
       `b`.`bookDate`        AS `bookDate`,
       `b`.`bookReceipt`     AS `bookReceipt`,
       `b`.`bookReceiptName` AS `bookReceiptName`,
       `b`.`bookStatus`      AS `bookStatus`,
       `b`.`bookFKmemberID`  AS `bookFKmemberID`,
       `b`.`bookFKSession`   AS `bookFKSession`,
       `b`.`bookFKGuestList` AS `bookFKGuestList`,
       `u`.`userName`        AS `userName`
from (`itp4511_project`.`bookingrecord` `b`
         left join `itp4511_project`.`user` `u` on (`b`.`bookFKmemberID` = `u`.`userID`));

