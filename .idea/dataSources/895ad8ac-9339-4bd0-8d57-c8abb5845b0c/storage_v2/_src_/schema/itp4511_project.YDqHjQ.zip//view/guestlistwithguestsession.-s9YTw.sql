create definer = root@localhost view guestlistwithguestsession as
select `gl`.`guestListID`           AS `guestListID`,
       `gl`.`guestListFKSession`    AS `guestListFKSession`,
       `gl`.`guestListFKguestID`    AS `guestListFKguestID`,
       `g`.`guestID`                AS `guestID`,
       `g`.`guestName`              AS `guestName`,
       `g`.`guestEmail`             AS `guestEmail`,
       `g`.`guestFKmemberID`        AS `guestFKmemberID`,
       `s`.`sessionID`              AS `sessionID`,
       `s`.`sessionDate`            AS `sessionDate`,
       `s`.`sessionStartTime`       AS `sessionStartTime`,
       `s`.`sessionEndTime`         AS `sessionEndTime`,
       `s`.`sessionCampus`          AS `sessionCampus`,
       `s`.`sessionStatus`          AS `sessionStatus`,
       `s`.`sessionFKbookingRecord` AS `sessionFKbookingRecord`
from ((`itp4511_project`.`guestlist` `gl` left join `itp4511_project`.`guest` `g` on (`gl`.`guestListFKguestID` = `g`.`guestID`))
         left join `itp4511_project`.`session` `s` on (`gl`.`guestListFKSession` = `s`.`sessionID`));

