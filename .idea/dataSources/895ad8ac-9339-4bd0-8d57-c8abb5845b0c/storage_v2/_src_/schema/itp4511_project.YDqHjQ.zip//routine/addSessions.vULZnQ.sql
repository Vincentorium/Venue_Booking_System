create
    definer = root@localhost procedure addSessions(IN start_date date, IN end_date date, IN campus_ID int)
BEGIN

	DECLARE current_my_date DATE;
    DECLARE start_time TIME;
    DECLARE end_time TIME;

 
 



    SET current_my_date = start_date;
    
    WHILE current_my_date <= end_date DO
    	    
            SET start_time = '09:00:00';
            WHILE HOUR(start_time) < 19 DO
                SET end_time = ADDTIME(start_time, '01:00:00');
                INSERT INTO session (	sessionCampus,sessionDate, sessionStartTime, sessionEndTime) 
                VALUES (campus_ID,current_my_date, start_time, end_time);
                SET start_time = ADDTIME(start_time, '01:00:00');
            END WHILE;
        	
            SET current_my_date = DATE_ADD(current_my_date, INTERVAL 1 DAY);
    END WHILE;
END;

