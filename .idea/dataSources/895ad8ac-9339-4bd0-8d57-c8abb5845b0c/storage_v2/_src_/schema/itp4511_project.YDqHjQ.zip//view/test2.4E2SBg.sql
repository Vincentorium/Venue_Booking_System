create definer = root@localhost view test2 as
select `itp4511_project`.`bookingrecord`.`bookID`          AS `bookID`,
       `itp4511_project`.`bookingrecord`.`bookDate`        AS `bookDate`,
       `itp4511_project`.`bookingrecord`.`bookReceipt`     AS `bookReceipt`,
       `itp4511_project`.`bookingrecord`.`bookReceiptName` AS `bookReceiptName`,
       `itp4511_project`.`bookingrecord`.`bookStatus`      AS `bookStatus`,
       `itp4511_project`.`bookingrecord`.`bookFKmemberID`  AS `bookFKmemberID`,
       `itp4511_project`.`bookingrecord`.`bookFKGuestList` AS `bookFKGuestList`,
       `itp4511_project`.`bookingrecord`.`bookReceiptDate` AS `bookReceiptDate`
from `itp4511_project`.`bookingrecord`
where 1;

