create definer = root@localhost view guestlistwithsessionandguestname as
select `s`.`sessionID`                     AS `sessionID`,
       `s`.`sessionDate`                   AS `sessionDate`,
       `s`.`sessionStartTime`              AS `sessionStartTime`,
       `s`.`sessionEndTime`                AS `sessionEndTime`,
       `s`.`sessionCampus`                 AS `sessionCampus`,
       `s`.`sessionStatus`                 AS `sessionStatus`,
       `s`.`sessionFKbookingRecord`        AS `sessionFKbookingRecord`,
       `s`.`sessionFKGuestlist`            AS `sessionFKGuestlist`,
       `mm`.`guestlistNGuestID`            AS `guestlistNGuestID`,
       `mm`.`guestlistNGuestFKguestlistID` AS `guestlistNGuestFKguestlistID`,
       `mm`.`guestlistNGuestFKguestID`     AS `guestlistNGuestFKguestID`,
       `g`.`guestID`                       AS `guestID`,
       `g`.`guestName`                     AS `guestName`,
       `g`.`guestEmail`                    AS `guestEmail`,
       `g`.`guestFKmemberID`               AS `guestFKmemberID`
from ((`itp4511_project`.`session` `s` left join `itp4511_project`.`guestlistenguest_mm` `mm` on (`s`.`sessionFKGuestlist` = `mm`.`guestlistNGuestFKguestlistID`))
         left join `itp4511_project`.`guest` `g` on (`mm`.`guestlistNGuestFKguestID` = `g`.`guestID`));

