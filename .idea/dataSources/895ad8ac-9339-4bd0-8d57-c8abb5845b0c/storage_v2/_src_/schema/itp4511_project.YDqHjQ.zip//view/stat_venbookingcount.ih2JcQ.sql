create definer = root@localhost view stat_venbookingcount as
select `v`.`venID`                                    AS `venID`,
       `v`.`venName`                                  AS `venName`,
       `ses`.`sessionDate`                            AS `sessionDate`,
       count(`ses`.`sessionID`)                       AS `bookingCount`,
       `v`.`venBookingFee` * count(`ses`.`sessionID`) AS `bookingRevenue`
from ((`itp4511_project`.`bookingrecord` `bkr` left join `itp4511_project`.`session` `ses` on (`bkr`.`bookID` = `ses`.`sessionFKbookingRecord`))
         left join `itp4511_project`.`venue` `v` on (`ses`.`sessionCampus` = `v`.`venID`))
where `ses`.`sessionStatus` = 1
  and `bkr`.`bookStatus` > 1
  and `ses`.`sessionDate` between '2023-01-26' and '2023-05-30'
group by `ses`.`sessionDate`, `ses`.`sessionCampus`
order by `ses`.`sessionCampus`;

