create definer = root@localhost view userinfo as
select `itp4511_project`.`user`.`userID`       AS `userID`,
       `itp4511_project`.`user`.`userName`     AS `userName`,
       `itp4511_project`.`user`.`userAcc`      AS `userAcc`,
       `itp4511_project`.`user`.`userPassword` AS `userPassword`,
       `itp4511_project`.`user`.`userType`     AS `userType`,
       `itp4511_project`.`user`.`userEmail`    AS `userEmail`,
       `itp4511_project`.`role`.`roleID`       AS `roleID`,
       `itp4511_project`.`role`.`roleTitle`    AS `roleTitle`
from (`itp4511_project`.`user`
         left join `itp4511_project`.`role`
                   on (`itp4511_project`.`user`.`userType` = `itp4511_project`.`role`.`roleID`));

