create
    definer = root@localhost procedure insert_session(IN camp int(255))
BEGIN
    DECLARE counter INT DEFAULT 0;
    DECLARE startTime TIME;

    SET startTime = '09:00:00';

    WHILE counter < 10 DO
        INSERT INTO session (sessionID , sessionDate, sessionStartTime, 	sessionEndTime,	sessionCampus,sessionStatus) 
        VALUES (null,now(), startTime, DATE_ADD(startTime, INTERVAL 1 HOUR), camp,0);

        SET startTime = DATE_ADD(startTime, INTERVAL 1 HOUR);
        SET counter = counter + 1;
    END WHILE;
END;

