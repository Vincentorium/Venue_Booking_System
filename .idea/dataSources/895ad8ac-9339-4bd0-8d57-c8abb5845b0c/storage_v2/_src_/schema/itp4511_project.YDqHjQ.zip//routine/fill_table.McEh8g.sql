create
    definer = root@localhost procedure fill_table()
BEGIN
    DECLARE counter INT DEFAULT 0;
    DECLARE startTime DATETIME;

    SET startTime = '09:00:00';

    WHILE counter < 10 DO
        INSERT INTO testsession (s, e) 
        VALUES (startTime, DATE_ADD(startTime, INTERVAL 1 HOUR));

        SET startTime = DATE_ADD(startTime, INTERVAL 1 HOUR);
        SET counter = counter + 1;
    END WHILE;
END;

