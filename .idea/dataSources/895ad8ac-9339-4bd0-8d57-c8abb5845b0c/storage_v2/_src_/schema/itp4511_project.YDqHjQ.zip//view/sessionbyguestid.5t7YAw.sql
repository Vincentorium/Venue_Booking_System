create definer = root@localhost view sessionbyguestid as
select `gmm`.`guestlistNGuestID`            AS `guestlistNGuestID`,
       `gmm`.`guestlistNGuestFKguestlistID` AS `guestlistNGuestFKguestlistID`,
       `gmm`.`guestlistNGuestFKguestID`     AS `guestlistNGuestFKguestID`,
       `s`.`sessionID`                      AS `sessionID`,
       `s`.`sessionDate`                    AS `sessionDate`,
       `s`.`sessionStartTime`               AS `sessionStartTime`,
       `s`.`sessionEndTime`                 AS `sessionEndTime`,
       `s`.`sessionCampus`                  AS `sessionCampus`,
       `s`.`sessionStatus`                  AS `sessionStatus`,
       `s`.`sessionFKbookingRecord`         AS `sessionFKbookingRecord`,
       `s`.`sessionFKGuestlist`             AS `sessionFKGuestlist`,
       `v`.`venID`                          AS `venID`,
       `v`.`venName`                        AS `venName`,
       `v`.`venType`                        AS `venType`,
       `v`.`venCapacity`                    AS `venCapacity`,
       `v`.`venLocation`                    AS `venLocation`,
       `v`.`venDescription`                 AS `venDescription`,
       `v`.`venPersonInCharge`              AS `venPersonInCharge`,
       `v`.`venBookingFee`                  AS `venBookingFee`,
       `v`.`venImage`                       AS `venImage`,
       `v`.`venCampus`                      AS `venCampus`
from ((`itp4511_project`.`guestlistenguest_mm` `gmm` left join `itp4511_project`.`session` `s` on (`s`.`sessionFKGuestlist` = `gmm`.`guestlistNGuestFKguestlistID`))
         left join `itp4511_project`.`venue` `v` on (`s`.`sessionCampus` = `v`.`venID`));

