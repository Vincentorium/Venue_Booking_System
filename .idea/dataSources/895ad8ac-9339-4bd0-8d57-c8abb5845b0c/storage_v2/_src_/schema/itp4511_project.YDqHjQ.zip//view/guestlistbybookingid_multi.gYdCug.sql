create definer = root@localhost view guestlistbybookingid_multi as
select `br`.`bookID`                AS `bookID`,
       `br`.`bookDate`              AS `bookDate`,
       `br`.`bookReceipt`           AS `bookReceipt`,
       `br`.`bookReceiptName`       AS `bookReceiptName`,
       `br`.`bookStatus`            AS `bookStatus`,
       `br`.`bookFKmemberID`        AS `bookFKmemberID`,
       `br`.`bookFKGuestList`       AS `bookFKGuestList`,
       `s`.`sessionID`              AS `sessionID`,
       `s`.`sessionDate`            AS `sessionDate`,
       `s`.`sessionStartTime`       AS `sessionStartTime`,
       `s`.`sessionEndTime`         AS `sessionEndTime`,
       `s`.`sessionCampus`          AS `sessionCampus`,
       `s`.`sessionStatus`          AS `sessionStatus`,
       `s`.`sessionFKbookingRecord` AS `sessionFKbookingRecord`,
       `gl`.`guestListID`           AS `guestListID`,
       `gl`.`guestListFKSession`    AS `guestListFKSession`,
       `gl`.`guestListFKguestID`    AS `guestListFKguestID`,
       `g`.`guestID`                AS `guestID`,
       `g`.`guestName`              AS `guestName`,
       `g`.`guestEmail`             AS `guestEmail`,
       `g`.`guestFKmemberID`        AS `guestFKmemberID`
from (((`itp4511_project`.`bookingrecord` `br` left join `itp4511_project`.`session` `s` on (`br`.`bookID` = `s`.`sessionFKbookingRecord`)) left join `itp4511_project`.`guestlist` `gl` on (`s`.`sessionID` = `gl`.`guestListFKSession`))
         left join `itp4511_project`.`guest` `g` on (`gl`.`guestListFKguestID` = `g`.`guestID`));

